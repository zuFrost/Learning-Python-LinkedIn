# Which code snippet can you use to print the number of digits in the number variable? 
# You can assume this number is always positive and always less than 10,000.

number = 9999

# if (number>=0):
#   print(1)
# elif (number>=10):
#   print(2)
# elif (number>=100):
#   print(3)
# else:
#   print(4)


# if (number<=10):
#   print(1)
# elif (number<=100):
#   print(2)
# elif (number<=1000):
#   print(3)
# else:
#   print(4)


if (number>=1000):
  print(4)
elif (number>=100):
  print(3)
elif (number>=10):
  print(2)
else:
  print(1)


# if (number<10000):
#   print(4)
# elif (number<1000):
#   print(3)
# elif (number<10):
#   print(2)
# else:
#   print(1)